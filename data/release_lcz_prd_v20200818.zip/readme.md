## Local Climate Zone - Pearl River Delta

For more information, please go to https://sjliu.me/lcz or email me (sjliu.me@gmail.com)

This LCZ map of the PRD region is generated from 2018-2019 Sentinel-2 composite images using the LCZNet [Liu and Shi, 2020] with an image size of 48*48. It covers the 9+2 cities of the PRD region and the surrounding areas. Note in the original paper, the LCZ map is generated from a single image snapshot. This new product aims at reducing the seasonal variation and providing a full coverage of the whole PRD region.

The PRD region: Guangzhou, Foshan, Zhaoqing, Shenzhen, Dongguan, Huizhou, Zhongshan, Jiangmen, Zhuhai, Macau, and Hong Kong (广州，佛山，肇庆，深圳，东莞，惠州，中山，江门，珠海，澳门，香港) 

The PRD administrative boundary is generated from the GADM project: https://gadm.org  

If you use this product, please kindly cite the original paper:

Liu, S. and Shi, Q., 2020. Local climate zone mapping as remote sensing scene classification using deep learning: A case study of metropolitan China. ISPRS Journal of Photogrammetry and Remote Sensing, 164, pp.229-242. 